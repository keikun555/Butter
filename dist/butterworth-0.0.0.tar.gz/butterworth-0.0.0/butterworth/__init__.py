"""
Kei Imada
Started 20170531
The init file for the filters package
"""
from butter import *
